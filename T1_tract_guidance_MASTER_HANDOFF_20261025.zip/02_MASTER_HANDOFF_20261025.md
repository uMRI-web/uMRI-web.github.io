# T1 tract guidance / MRI white-matter educational viewer — master handoff
Date: 2026-10-25
Owner: uMRI / Go Uruma
Purpose: loss-minimized continuation into a new ChatGPT thread.

## Core goal
Research target is NOT diagnosis and NOT individual true tractography reconstruction.
The target is T1-only educational white-matter tract guidance for beginners: 「このへんを見る」「白質路がおおよそどのあたりを走るかにあたりをつける」.
Keep “特定する” vs “あたりをつける” distinct.

## Model family
A1 = T1-only atlas deformation baseline. Prior simple attempt was confounded by legacy NIfTI geometry/header problems.
A2a = FA-informed atlas deformation. Successful single-subject PoC 2026-10-09.
A2b = tensor-informed registration candidate.
B = real paired T1+dMRI supervised AI.
C = SynthSeg-style/domain-randomized synthetic learning.
D = preferred likely main model: synthetic pretraining + real paired-data fine-tuning.

## A2a accepted result
Corrected final T1:
D:\MRI-AI-study\04_EXPERIMENTS\A2a_FA_atlas_deformation\20261009_poc\final_outputs\results_T1_final.nii.gz
WSL:
/mnt/d/MRI-AI-study/04_EXPERIMENTS/A2a_FA_atlas_deformation/20261009_poc/final_outputs/results_T1_final.nii.gz

Legacy original:
D:\MRI-AI-study\01_SUBJECT_DATA\book_sample_001\T1\original\test.nii.gz
Do NOT substitute legacy test.nii.gz when reproducing the final Viewer/SynthSeg path; it had geometry/qform/sform problems.

A2a pipeline:
subject FA -> FMRIB58_FA affine + FNIRT -> inverse warp -> standard probabilistic tract maps into subject FA -> FA-to-T1 rigid transform.
20 tract maps; 29 T1 probability outputs including bilateral combinations; 29 threshold-5 masks.
Fresh SynthSeg on corrected final T1.
77 atomic CORE/LANDMARK ROIs.
Tract/ROI/glass-brain meshes.
Representative visual QC passed.

## Viewer
Standard: https://umri-web.github.io/tract-viewer/
Individual A2a: https://umri-web.github.io/tract-viewer/nougazounoatarashiibennkyoubonnver/
Subject Viewer is public-but-unadvertised, not private.
noindex/nofollow/noarchive/nosnippet added only to subject Viewer.
Prior noindex commit: 69669a34352d374cbd7d0026dad3346fbc424dd7

Viewer disclaimer:
個人T1上の教育用表示。白質路はFA-informed atlas deformationによるガイドであり、個人の真のtractographyを意味しない。CORE/LANDMARKも厳密な線維終末を意味しない。

## Licensing
Current JHU-derived tract assets are appropriate for research prototype use but have noncommercial redistribution concerns.
Future commercial/book edition should use rights-clean assets.

## RunPod archive
A2a_COMPLETE_BACKUP_20261009.tar.gz
594 source files.
Local SHA256 verified:
9691fd656970331fc711b69c6385748ef567d5b8cb483f92d883c794fbbb1505
RunPod stopped only after verification.

## Ethics
Core AI research planned with public/anonymous existing T1+dMRI datasets, no new participants or local clinical/EHR data.
Do not categorically claim ethics exemption; say likely outside scope/exempt by design, subject to institution and dataset Data Use Terms.

## Book context
Current book being produced is a literature-review book and may contain a teaser/manga for this AI project.
Future 『脳画像の新しい勉強本 第2版』 is the intended home for the final rights-clean Viewer; ideal 2027, latest 2029.

## New RTX 3090 PC — current state
Alienware Aurora R11; RTX 3090 24GB; WSL2 Ubuntu 24.04.x; D: physical 2TB SATA SSD.
User prefers D: for research data/work and does not want C: dirtied unnecessarily.
Windows tools downloaded/installed: ITK-SNAP, 3D Slicer, dcm2niix.

FSL:
6.0.7.23 installed /home/umri/fsl.
which flirt -> /home/umri/fsl/share/fsl/bin/flirt
flirt -version -> FLIRT version 6.0
FSLDIR=/home/umri/fsl

FreeSurfer/SynthSeg:
FreeSurfer 8.2.0 installed /usr/local/freesurfer/8.2.0.
mri_synthseg -> /usr/local/freesurfer/8.2.0/bin/mri_synthseg
License source D:\MRI-AI-study\90_TOOLS\freesurfer_license.txt
Copied to /home/umri/license.txt
FS_LICENSE=/home/umri/license.txt
FREESURFER_HOME=/usr/local/freesurfer/8.2.0
~/.bashrc sources SetUpFreeSurfer.sh.
mri_synthseg --help worked; SynthSeg 2.0.

IMPORTANT: Do not mix old-PC installations with this new PC. FSL/FreeSurfer/SynthSeg were installed in this thread.

## CURRENT LIVE TASK
Reproduce SAME subject used by nougazounoatarashiibennkyoubonnver Viewer, then continue through full FreeSurfer.

Output:
D:\MRI-AI-study\02_PREPROCESSING\SynthSeg\local3090_20261025
WSL:
/mnt/d/MRI-AI-study/02_PREPROCESSING/SynthSeg/local3090_20261025

Running command:
time mri_synthseg \
  --i "/mnt/d/MRI-AI-study/04_EXPERIMENTS/A2a_FA_atlas_deformation/20261009_poc/final_outputs/results_T1_final.nii.gz" \
  --o "subject_seg_parc_1mm.nii.gz" \
  --parc \
  --resample "subject_T1_synthseg_1mm.nii.gz" \
  --vol "subject_vol_parc.csv"

Last screenshot:
SynthSeg 2.0
using 1 thread
addctab True
predicting 1/1

Process has started correctly, but completion is NOT yet confirmed.

At start, nvidia-smi showed RTX 3090 with ~9895 MiB / 24576 MiB in use, ~27% util, 55C, 92W/300W.
User explicitly said ICF bot GPU work is running concurrently.
Do not assume the displayed GPU usage belongs to SynthSeg.

## Next thread
1. Verify SynthSeg returned to shell and outputs exist:
   subject_seg_parc_1mm.nii.gz
   subject_T1_synthseg_1mm.nii.gz
   subject_vol_parc.csv
2. QC/compare with prior RunPod result if useful.
3. Continue SAME corrected T1 to full FreeSurfer recon-all.
4. User explicitly wants 「最終的にfreesurferまで回したい」.
5. Respect D: preference when choosing recon-all output/archival layout.
6. One terminal stage at a time.

## Work style
Short commands may be pasted.
Long Python/BAT/shell scripts should be downloadable files, not giant pasted code.
Do not re-decide accepted architecture.
Continuity > small cloud cost savings; preserve results before stopping/destructive cleanup.
