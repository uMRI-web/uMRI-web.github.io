# Figure / manga handoff

## CST lesion-load comic figure
User supplied a manga page about CST lesion load / wCST-LL (Feng et al., Ann Neurol 2015 context) and requested a clearer three-image scientific sequence:
1. Patient brain DWI with hyperintense lesion on the CST region.
2. Standard-brain DWI with CST ROI overlaid.
3. Same patient DWI with the ROI from #2 warped to patient anatomy; overlap highlighted.
PNG is sufficient; DICOM not required. Patient brain may be only slightly deformed from standard brain.

Three concept images were generated in-thread:
- 急性期DWI病変
- canonical CST（確率地図）
- wCST-LL
They are explanatory generated graphics, not measured patient tractography/data. For publication-grade figures, prefer explicit NIfTI/mask rendering.

## CST / SLF / IFOF schematic
A final small black-and-white schematic exists, labeled:
- 皮質脊髄路 (CST)
- 上縦束 (SLF)
- 下前頭後頭束 (IFOF)
User deleted the long creation subthread to reduce thread length and asked that the final figure/context be retained. If editing resumes, start from the attached final schematic, not deleted intermediate history.

## Abstract result sentence — accepted wording
SynthSegによる個人脳parcellationから77の解剖学的ROIを抽出し、白質路、CORE、LANDMARK、および3D脳表を同時表示するWeb Viewer（https://umri-web.github.io/tract-viewer/）を用いて、代表白質路について目視確認を行った。その結果、T1画像、白質路および関連ROIの位置関係に明らかな破綻を認めなかった。
