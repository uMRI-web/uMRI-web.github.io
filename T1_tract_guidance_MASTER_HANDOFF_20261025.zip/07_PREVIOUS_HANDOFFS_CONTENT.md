# Previous handoff packages identified in source conversation

1. FreeSurfer_RunPod_handoff_2026-09-27.zip
2. 邪道新刊_総括引継ぎ_脳画像Web特典構想_2026-09-27.zip
3. T1_tract_guidance_master_handoff_2026-10-05.zip

Their operational content is carried forward into this bundle:
- FreeSurfer RunPod/recon-all continuity.
- Book/Web benefit Viewer concept.
- T1 tract-guidance architecture, ethics/research framing, Viewer state, accepted model variants.

Technical limitation during this handoff build:
The session's normal sandbox execution service was unavailable, so older ZIP binaries could not be byte-for-byte nested/extracted into this newly generated ZIP. Their original files remain attached to the source conversation and were separately materialized for direct download. Their CONTENT has been merged/reconstructed here; do not claim original ZIP bytes are nested.

Later accepted decisions in 02_MASTER_HANDOFF supersede older summaries where they differ.
